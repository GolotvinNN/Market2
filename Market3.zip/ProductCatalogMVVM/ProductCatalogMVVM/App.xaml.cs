﻿using System.Windows;
using ProductCatalogMVVM.View;

namespace ProductCatalogMVVM
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Создаем экземпляр окна Login
            LoginWindow loginWindow = new LoginWindow();

            // Устанавливаем его как главное окно приложения
            Current.MainWindow = loginWindow;

            // Отображаем окно
            loginWindow.Show();
        }
    }
}

