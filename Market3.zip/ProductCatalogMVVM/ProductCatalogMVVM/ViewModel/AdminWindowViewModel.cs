﻿using Prism.Commands;
using Prism.Mvvm;
using ProductCatalogMVVM.Model;
using ProductCatalogMVVM.View;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace ProductCatalogMVVM.ViewModel
{
    public class AdminWindowViewModel : BindableBase
    {
        private string _productName;
        private string _productPrice;
        private Product _selectedProduct;
        private ObservableCollection<Product> _products;
        private ObservableCollection<Product> _filteredProducts;

        public ObservableCollection<Product> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }

        public ObservableCollection<Product> FilteredProducts
        {
            get => _filteredProducts;
            set => SetProperty(ref _filteredProducts, value);
        }

        public Product SelectedProduct
        {
            get => _selectedProduct;
            set => SetProperty(ref _selectedProduct, value);
        }

        public string ProductName
        {
            get => _productName;
            set => SetProperty(ref _productName, value);
        }

        public string ProductPrice
        {
            get => _productPrice;
            set => SetProperty(ref _productPrice, value);
        }

        public DelegateCommand UpdateProductCommand { get; }
        public DelegateCommand AddProductCommand { get; }
        public DelegateCommand DeleteProductCommand { get; }
        public DelegateCommand BackToAuthorizationCommand { get; }
        public DelegateCommand ExitCommand { get; }
        public DelegateCommand SearchCommand { get; }

        public AdminWindowViewModel()
        {
            LoadProducts();
            FilteredProducts = Products;

            UpdateProductCommand = new DelegateCommand(OnUpdateProduct);
            AddProductCommand = new DelegateCommand(OnAddProduct);
            DeleteProductCommand = new DelegateCommand(OnDeleteProduct);
            BackToAuthorizationCommand = new DelegateCommand(OnBackToAuthorization);
            ExitCommand = new DelegateCommand(OnExit);
            SearchCommand = new DelegateCommand(OnSearch);
        }

        private void LoadProducts()
        {
            using (var dbContext = new ProductCatalogDBContext())
            {
                Products = new ObservableCollection<Product>(dbContext.GetAllProducts());
            }
        }

        private void OnUpdateProduct()
        {
            if (SelectedProduct != null)
            {
                if (!string.IsNullOrWhiteSpace(ProductName) && !string.IsNullOrWhiteSpace(ProductPrice))
                {
                    double price;
                    if (double.TryParse(ProductPrice, out price))
                    {
                        SelectedProduct.Name = ProductName;
                        SelectedProduct.Price = price;

                        using (var dbContext = new ProductCatalogDBContext())
                        {
                            dbContext.UpdateProduct(SelectedProduct);
                        }

                        // Обновляем список продуктов
                        LoadProducts();

                        MessageBox.Show("Продукт успешно обновлен.");
                    }
                    else
                    {
                        MessageBox.Show("Цена должна быть числом.");
                    }
                }
                else
                {
                    MessageBox.Show("Заполните все поля.");
                }
            }
            else
            {
                MessageBox.Show("Выберите продукт для обновления.");
            }
        }

        private void OnAddProduct()
        {
            if (!string.IsNullOrWhiteSpace(ProductName) && !string.IsNullOrWhiteSpace(ProductPrice))
            {
                double price;
                if (double.TryParse(ProductPrice, out price))
                {
                    var newProduct = new Product { Name = ProductName, Price = price };
                    new ProductCatalogDBContext().AddProduct(newProduct);
                    Products.Add(newProduct);
                    MessageBox.Show("Product added successfully.");
                    ProductName = "";
                    ProductPrice = "";
                }
                else
                {
                    MessageBox.Show("Price must be a valid number.");
                }
            }
            else
            {
                MessageBox.Show("Please fill in all fields.");
            }
        }

        private void OnDeleteProduct()
        {
            if (SelectedProduct != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    using (var dbContext = new ProductCatalogDBContext())
                    {
                        dbContext.DeleteProduct(SelectedProduct.Id);
                    }

                    // Удаляем выбранный товар из коллекции Products
                    Products.Remove(SelectedProduct);

                    MessageBox.Show("Товар успешно удален.");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите товар для удаления.");
            }
        }

        private void OnBackToAuthorization()
        {
            Application.Current.MainWindow = new LoginWindow();
            Application.Current.MainWindow.Show();
            foreach (Window window in Application.Current.Windows)
            {
                if (window != Application.Current.MainWindow)
                {
                    window.Close();
                }
            }
        }

        private void OnExit()
        {
            Application.Current.Shutdown();
        }

        private void OnSearch()
        {
            if (string.IsNullOrWhiteSpace(ProductName))
            {
                FilteredProducts = Products;
            }
            else
            {
                FilteredProducts = new ObservableCollection<Product>(
                    Products.Where(p => p.Name.ToLower().Contains(ProductName.ToLower())));
            }
        }
    }
}











