﻿using Prism.Commands;
using Prism.Mvvm;
using ProductCatalogMVVM.View;
using System.Windows;

namespace ProductCatalogMVVM.ViewModel
{
    public class LoginWindowViewModel : BindableBase
    {
        private string _username;

        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        public DelegateCommand LoginCommand { get; }
        public DelegateCommand ExitCommand { get; }

        public LoginWindowViewModel()
        {
            LoginCommand = new DelegateCommand(OnLogin);
            ExitCommand = new DelegateCommand(OnExit);
        }

        private void OnLogin()
        {
            if (Username == "admin")
            {
                OpenAdminWindow();
            }
            else if (Username == "user")
            {
                OpenUserWindow();
            }
            else
            {
                MessageBox.Show("Invalid username.");
            }
        }

        private void OpenAdminWindow()
        {
            Application.Current.MainWindow = new AdminWindow();
            Application.Current.MainWindow.Show();
            foreach (Window window in Application.Current.Windows)
            {
                if (window != Application.Current.MainWindow)
                {
                    window.Close();
                }
            }
        }

        private void OpenUserWindow()
        {
            Application.Current.MainWindow = new UserWindow();
            Application.Current.MainWindow.Show();
            foreach (Window window in Application.Current.Windows)
            {
                if (window != Application.Current.MainWindow)
                {
                    window.Close();
                }
            }
        }

        private void OnExit()
        {
            Application.Current.Shutdown();
        }
    }
}













