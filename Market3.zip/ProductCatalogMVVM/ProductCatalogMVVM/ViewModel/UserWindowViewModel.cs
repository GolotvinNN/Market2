﻿using Prism.Commands;
using Prism.Mvvm;
using ProductCatalogMVVM.Model;
using ProductCatalogMVVM.View;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;

namespace ProductCatalogMVVM.ViewModel
{
    public class UserWindowViewModel : BindableBase
    {
        private ProductCatalogDBContext _dbContext = new ProductCatalogDBContext();
        private ObservableCollection<Product> _products = new ObservableCollection<Product>();

        public ObservableCollection<Product> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }

        public DelegateCommand SearchCommand { get; }
        public DelegateCommand BackToAuthorizationCommand { get; }
        public DelegateCommand ExitCommand { get; }

        private string _searchTerm;

        public string SearchTerm
        {
            get => _searchTerm;
            set => SetProperty(ref _searchTerm, value);
        }

        public UserWindowViewModel()
        {
            SearchCommand = new DelegateCommand(OnSearch);
            BackToAuthorizationCommand = new DelegateCommand(OnBackToAuthorization);
            ExitCommand = new DelegateCommand(OnExit);
            LoadProducts();
        }

        private void LoadProducts()
        {
            Products = new ObservableCollection<Product>(_dbContext.GetAllProducts());
        }

        private void OnSearch()
        {
            if (string.IsNullOrWhiteSpace(SearchTerm))
            {
                LoadProducts();
            }
            else
            {
                Products = new ObservableCollection<Product>(_dbContext.SearchProducts(SearchTerm));
            }
        }

        private void OnBackToAuthorization()
        {
            Application.Current.MainWindow = new LoginWindow();
            Application.Current.MainWindow.Show();
            foreach (Window window in Application.Current.Windows)
            {
                if (window != Application.Current.MainWindow)
                {
                    window.Close();
                }
            }
        }

        private void OnExit()
        {
            Application.Current.Shutdown();
        }
    }
}
