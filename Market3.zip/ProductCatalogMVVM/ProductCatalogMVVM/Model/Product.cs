﻿using System;
using System.ComponentModel.DataAnnotations;
namespace ProductCatalogMVVM.Model
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public override string ToString()
        {
            return $"{Name} - {Price:C2}";
        }
    }
}

